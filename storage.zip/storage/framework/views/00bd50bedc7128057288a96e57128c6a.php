

<?php $__env->startSection('title', 'Tambah Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-custom p-4">
    <h4 class="mb-3">Tambah Mahasiswa</h4>

    <form action="<?php echo e(route('mahasiswa.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <input class="form-control mb-2" name="name" placeholder="Nama" required>
        <input class="form-control mb-2" name="email" placeholder="Email" required>
        <input class="form-control mb-2" name="nim" placeholder="NIM" required>
        <input class="form-control mb-2" name="prodi" placeholder="Prodi" required>
        <input class="form-control mb-3" name="nohp" placeholder="No HP" required>

        <button class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PBW\pwb_ti_2024\resources\views/create.blade.php ENDPATH**/ ?>