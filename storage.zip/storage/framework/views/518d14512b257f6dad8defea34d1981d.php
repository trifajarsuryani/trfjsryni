

<?php $__env->startSection('title', 'Berita'); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-custom p-4">
    <h3 class="mb-4">Berita Terbaru</h3>

    <?php
        $daftarBerita = [
            [
                'judul' => 'Perubahan Kurikulum 2025',
                'isi' => 'Pemerintah mengumumkan perubahan kurikulum nasional yang akan berlaku mulai tahun ajaran depan. Fokus pada teknologi dan literasi digital.'
            ],
            [
                'judul' => 'Inovasi Teknologi Hijau',
                'isi' => 'Startup meluncurkan teknologi ramah lingkungan yang mampu mengurangi polusi dan limbah industri.'
            ],
            [
                'judul' => 'Festival Budaya Lokal',
                'isi' => 'Festival budaya digelar dengan pertunjukan seni tradisional, kuliner khas, dan bazar UMKM.'
            ],
        ];
    ?>

    <?php $__currentLoopData = $daftarBerita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-4 p-3 border rounded bg-light">
            <h5><?php echo e($berita['judul']); ?></h5>
            <p><?php echo e($berita['isi']); ?></p>
            <a href="#" class="btn btn-sm btn-primary">Read More</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PBW\pwb_ti_2024\resources\views/berita.blade.php ENDPATH**/ ?>