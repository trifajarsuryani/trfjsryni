

<?php $__env->startSection('content'); ?>
<div class="container mt-5">

    <div class="card shadow-sm">
        <div class="card-body">

            <h2 class="card-title text-center mb-4">Dashboard</h2>

            <p class="text-center">
                Selamat datang, <strong><?php echo e(auth()->user()->name); ?></strong>!
            </p>

            <p class="text-center">
                Kamu sudah berhasil login 👏
            </p>

            <div class="text-center mt-3">
                <a href="<?php echo e(route('mahasiswa.index')); ?>" class="btn btn-primary">
                    Lihat Data Mahasiswa
                </a>
            </div>

        </div>  
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\PBW\pwb_ti_2024\resources\views/dashboard.blade.php ENDPATH**/ ?>